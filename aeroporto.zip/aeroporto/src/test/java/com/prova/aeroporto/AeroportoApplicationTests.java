package com.prova.aeroporto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AeroportoApplicationTests {

	@Test
	void contextLoads() {
	}

}
