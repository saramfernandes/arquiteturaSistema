package com.prova.aeroporto.infraestrutura.controller;

public record AeroportoRequest(String nome, String cidade, String estado, String codigoATA, String telefone) {
    
}
