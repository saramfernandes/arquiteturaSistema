package com.prova.aeroporto.domain;

public record Aeroporto(String nome, String cidade, String estado, String codigoATA, String telefone) {
    
}
