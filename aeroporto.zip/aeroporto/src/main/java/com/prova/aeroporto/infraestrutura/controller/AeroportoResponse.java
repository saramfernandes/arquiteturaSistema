package com.prova.aeroporto.infraestrutura.controller;

public record AeroportoResponse(String nome, String telefone) {
    
}
