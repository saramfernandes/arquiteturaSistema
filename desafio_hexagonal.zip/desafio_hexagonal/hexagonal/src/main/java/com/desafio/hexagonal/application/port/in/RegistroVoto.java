package com.desafio.hexagonal.application.port.in;

public class RegistroVoto {
    
}
